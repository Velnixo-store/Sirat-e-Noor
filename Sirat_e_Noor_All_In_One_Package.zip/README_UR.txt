SIRAT-E-NOOR — ALL-IN-ONE STARTER PACKAGE

This ZIP contains:
- Flutter app source
- Urdu RTL interface
- Emerald green + gold theme
- 18 Islamic topic sections
- Search and bookmarks
- Codemagic Android APK build configuration (codemagic.yaml)
- GitHub Actions workflow placeholder directory

IMPORTANT:
This is a starter app, not a finished religious-content app or a prebuilt APK.
The sections are currently navigation/content placeholders. Quran text, translations,
hadith, duas, audio, prayer times, offline databases and full fiqh content still need
to be added and checked against reliable Sunni Hanafi/Barelvi references. Obtain
permission for copyrighted translations and audio.

MOBILE UPLOAD NOTE:
Extract this ZIP on your phone. Upload the CONTENTS (not the ZIP itself) to the
root of your GitHub repository, keeping folder structure. The root should contain:
pubspec.yaml, lib/main.dart, codemagic.yaml, README_UR.txt.
Then connect the repository to Codemagic and start the Android workflow.
Codemagic may ask you to sign in and authorize access to the repository.
Build services and their free-tier limits can change.

If using a local computer with Flutter:
  flutter pub get
  flutter create --platforms=android --project-name sirat_e_noor .
  flutter build apk --release

APK output:
  build/app/outputs/flutter-apk/app-release.apk
