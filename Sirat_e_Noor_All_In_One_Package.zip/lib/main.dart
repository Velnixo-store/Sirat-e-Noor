import 'package:flutter/material.dart';

void main() => runApp(const SiratENoorApp());

const green = Color(0xFF075B46);
const gold = Color(0xFFD7B56D);

class SiratENoorApp extends StatelessWidget {
  const SiratENoorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'صراطِ نور',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF7F8F4),
      appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white, centerTitle: true),
    ),
    home: const HomePage(),
  );
}

class Topic {
  final String title, subtitle;
  final IconData icon;
  const Topic(this.title, this.subtitle, this.icon);
}

const topics = <Topic>[
  Topic('قرآنِ پاک', '114 سورتیں، ترجمہ، تلاوت اور بک مارک', Icons.menu_book),
  Topic('نماز کا طریقہ', 'نماز اور ضروری اذکار', Icons.mosque),
  Topic('وضو اور غسل', 'طہارت کے بنیادی مسائل', Icons.water_drop),
  Topic('نمازِ جنازہ', 'طریقہ اور متعلقہ دعائیں', Icons.volunteer_activism),
  Topic('مسنون دعائیں', 'روزمرہ کی دعائیں اور اذکار', Icons.auto_awesome),
  Topic('اسمائے حسنیٰ', 'اللہ تعالیٰ کے 99 نام', Icons.star),
  Topic('درود و سلام', 'درود شریف مع حوالہ جات', Icons.favorite),
  Topic('حدیثِ مبارکہ', 'منتخب احادیث مع مستند حوالہ', Icons.menu_book_outlined),
  Topic('سیرت النبی ﷺ', 'حضور ﷺ کی مبارک زندگی', Icons.history_edu),
  Topic('انبیائے کرام کے قصے', 'سبق آموز واقعات', Icons.auto_stories),
  Topic('رمضان گائیڈ', 'روزہ، تراویح اور زکوٰۃ', Icons.nightlight_round),
  Topic('اسلامی کیلنڈر', 'ہجری تاریخ اور اہم ایام', Icons.calendar_month),
  Topic('ڈیجیٹل تسبیح', 'تسبیحات گننے کا ٹول', Icons.toll),
  Topic('نماز ٹریکر', 'ذاتی نماز ریکارڈ', Icons.check_circle_outline),
  Topic('اسلامی کوئز', 'سوالات اور معلومات', Icons.quiz),
  Topic('بچوں کا گوشہ', 'آسان دینی تعلیم اور کہانیاں', Icons.child_care),
  Topic('فقہِ اہلِ سنت', 'حنفی و بریلوی مراجع سے رہنمائی', Icons.library_books),
  Topic('آڈیو لائبریری', 'تلاوت اور دعاؤں کی آڈیو', Icons.headphones),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';
  final search = TextEditingController();
  final saved = <String>{};
  @override
  void dispose() { search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final visible = topics.where((t) =>
      (t.title.contains(query) || t.subtitle.contains(query)) &&
      (tab == 0 || saved.contains(t.title))).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('صراطِ نور', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [IconButton(onPressed: () => showAboutDialog(
            context: context, applicationName: 'صراطِ نور', applicationVersion: '1.0.0',
            children: const [Text('قرآن و سنت کی روشنی میں آسان دینی تعلیم')],
          ), icon: const Icon(Icons.info_outline))],
        ),
        body: Column(children: [
          Container(
            width: double.infinity, margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [green, Color(0xFF118365)]),
              borderRadius: BorderRadius.circular(18)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('قرآن و سنت کی روشنی میں', style: TextStyle(color: gold)),
              SizedBox(height: 8),
              Text('دین سیکھیں، آسان انداز میں', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 5),
              Text('آپ کی دینی رہنمائی کا ایک آسان مرکز', style: TextStyle(color: Colors.white70)),
            ]),
          ),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(
            controller: search, onChanged: (v) => setState(() => query = v.trim()),
            decoration: InputDecoration(
              hintText: 'موضوع تلاش کریں...', prefixIcon: const Icon(Icons.search),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
          )),
          const SizedBox(height: 8),
          Expanded(child: visible.isEmpty
            ? const Center(child: Text('کوئی موضوع نہیں ملا۔'))
            : GridView.builder(
              padding: const EdgeInsets.all(14), itemCount: visible.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, childAspectRatio: 1.22, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemBuilder: (context, i) {
                final t = visible[i]; final isSaved = saved.contains(t.title);
                return Card(color: Colors.white, elevation: 1,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: InkWell(borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TopicPage(topic: t))),
                    child: Padding(padding: const EdgeInsets.all(12), child: Column(
                      mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(t.icon, color: green, size: 30), const SizedBox(height: 8),
                        Text(t.title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 4),
                        Text(t.subtitle, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11, color: Colors.black54)),
                        Align(alignment: Alignment.bottomLeft, child: IconButton(
                          visualDensity: VisualDensity.compact,
                          icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_border, color: isSaved ? gold : green),
                          onPressed: () => setState(() => isSaved ? saved.remove(t.title) : saved.add(t.title)),
                        )),
                      ]))),
                );
              })),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() { tab = v; query = ''; search.clear(); }),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'ہوم'),
            NavigationDestination(icon: Icon(Icons.bookmark_outline), selectedIcon: Icon(Icons.bookmark), label: 'محفوظ'),
          ]),
      ),
    );
  }
}

class TopicPage extends StatelessWidget {
  final Topic topic;
  const TopicPage({super.key, required this.topic});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: Text(topic.title)),
      body: Padding(padding: const EdgeInsets.all(22), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(topic.icon, color: green, size: 48), const SizedBox(height: 16),
          Text(topic.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10), Text(topic.subtitle, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 24),
          const Text('اس حصے کا اصل مواد اگلے مرحلے میں مستند عربی متن، اردو ترجمہ، آڈیو اور حوالہ جات کے ساتھ شامل کیا جائے گا۔',
            style: TextStyle(fontSize: 16, height: 1.8)),
          const SizedBox(height: 12),
          const Text('قرآن، حدیث اور فقہی مسائل کو شائع کرنے سے پہلے مستند اہلِ علم سے جانچنا ضروری ہے۔',
            style: TextStyle(color: green, height: 1.7)),
        ]))),
  );
}
